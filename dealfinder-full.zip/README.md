# DealFinder — Full Automation

Project ready for deployment: frontend static site + Node.js server with full automation for:
- importing listings (CSV / feed URLs)
- rewriting descriptions via OpenAI
- scheduled feed polling (cron)
- SQLite database (bundled)

## Quickstart (local)

1. Install Node 18+ and npm.
2. Copy `.env.example` to `.env` and set values (OPENAI_API_KEY, FEED_URLS, DATABASE_PATH).
3. From `server/`:
   ```bash
   cd server
   npm install
   npm run start
   ```
4. Visit `http://localhost:3000`

## Deploy
You can deploy the `server` to Render, Railway, Fly.io, Heroku, or Vercel (serverless functions may need adaptation).
- Provide `OPENAI_API_KEY` as secret.
- Set `FEED_URLS` environment variable with newline-separated feed URLs (JSON array or newline list).
- Optional: use Dockerfile for container deploy.

## Endpoints
- `GET /api/listings` — all listings (includes rewrittenDescription)
- `POST /api/import` — upload CSV file (field name `file`)
- `POST /api/refresh` — trigger immediate feed import
- `POST /api/rewrite` — body `{id: '<listing-id>'}` to re-run rewriting

## CSV headers
`id,title,city,area,price,size,pricePerSqm,type,tags,description,source,cityMedian`

## Notes & next steps
- OpenAI usage costs will apply when `OPENAI_API_KEY` is set.
- For production, enable HTTPS and restrict access to admin endpoints.
- Consider caching rewritten descriptions to avoid repeated API calls.
