
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const multer = require('multer');
const csvParse = require('csv-parse');
const fs = require('fs');
const path = require('path');
const { init, insertOrUpdate, getAll } = require('./db');
const OpenAI = require('openai');
const cron = require('node-cron');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..'))); // serve frontend static files

init();

const upload = multer({ dest: 'uploads/' });

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || ''
});

// Helper: rewrite description via OpenAI
async function rewriteDescriptionOpenAI(text){
  if(!process.env.OPENAI_API_KEY) return text + " (rescriere off - lipsa cheie OpenAI)";
  try{
    const prompt = "Rescrie în limba română textul următor pentru un site imobiliar: păstrează toate ideile autorului, fă-l natural, 2-3 propoziții, evită clişeele comerciale. Text: \"" + text + "\"";
    const resp = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{role:'user', content: prompt}],
      max_tokens: 200,
      temperature: 0.7
    });
    const content = resp.choices && resp.choices[0] && resp.choices[0].message && resp.choices[0].message.content;
    return content ? content.trim() : text;
  }catch(e){
    console.error('OpenAI rewrite failed', e.message || e);
    return text;
  }
}

// Endpoint: get listings
app.get('/api/listings', (req,res)=>{
  const rows = getAll();
  res.json(rows);
});

// Endpoint: manual refresh trigger (calls feeds)
app.post('/api/refresh', async (req,res)=>{
  try{
    await fetchFeedsOnce();
    res.json({ok:true});
  }catch(e){
    res.status(500).json({error: String(e)});
  }
});

// Endpoint: CSV upload (import)
app.post('/api/import', upload.single('file'), async (req,res)=>{
  const file = req.file;
  if(!file) return res.status(400).json({error:'no file'});
  const txt = fs.readFileSync(file.path, 'utf8');
  csvParse(txt, {columns:true, trim:true}, async (err, records)=>{
    if(err) return res.status(500).json({error:String(err)});
    for(const r of records){
      const listing = mapRecordToListing(r);
      listing.rewrittenDescription = await rewriteDescriptionOpenAI(listing.description || '');
      insertOrUpdate(listing);
    }
    fs.unlinkSync(file.path);
    res.json({imported: records.length});
  });
});

function mapRecordToListing(r){
  return {
    id: r.id || (r.source||'csv') + '-' + Date.now() + '-' + Math.random().toString(36).slice(2,8),
    title: r.title || '',
    city: r.city || '',
    area: r.area || '',
    price: parseFloat(r.price) || 0,
    size: parseFloat(r.size) || 0,
    pricePerSqm: parseFloat(r.pricePerSqm) || (r.price && r.size ? parseFloat(r.price)/parseFloat(r.size) : 0),
    type: r.type || 'rent',
    tags: JSON.stringify((r.tags || '').split(/[,;|]/).map(s=>s.trim()).filter(Boolean)),
    description: r.description || '',
    rewrittenDescription: r.rewrittenDescription || '',
    cityMedian: parseFloat(r.cityMedian) || null,
    source: r.source || 'csv',
    createdAt: new Date().toISOString()
  };
}

// Endpoint: rewrite specific id (re-run OpenAI)
app.post('/api/rewrite', express.json(), async (req,res)=>{
  const { id } = req.body;
  if(!id) return res.status(400).json({error:'no id'});
  const rows = getAll();
  const r = rows.find(x=>x.id===id);
  if(!r) return res.status(404).json({error:'not found'});
  const newText = await rewriteDescriptionOpenAI(r.description || '');
  insertOrUpdate(Object.assign({}, r, {rewrittenDescription:newText}));
  res.json({ok:true, rewritten:newText});
});

// Simple feed fetcher: you can configure FEED_URLS in env as JSON array or newline-separated
async function fetchFeedsOnce(){
  const feedsRaw = process.env.FEED_URLS || '';
  const feeds = feedsRaw.split(/\\n/).map(s=>s.trim()).filter(Boolean);
  for(const url of feeds){
    try{
      const resp = await fetch(url);
      if(!resp.ok) continue;
      const data = await resp.json();
      for(const item of data){
        const listing = mapRecordToListing(item);
        listing.rewrittenDescription = await rewriteDescriptionOpenAI(listing.description || '');
        insertOrUpdate(listing);
      }
    }catch(e){
      console.error('feed fetch failed', url, e.message || e);
    }
  }
}

// Cron: run every 30 minutes
cron.schedule(process.env.CRON_SCHEDULE || '*/30 * * * *', ()=>{
  console.log('Cron job: fetching feeds...');
  fetchFeedsOnce().catch(e=>console.error('cron fetch failed', e));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server listening on', PORT));
