const Database = require('better-sqlite3');
const dbPath = process.env.DATABASE_PATH || './server/data.db';
const db = new Database(dbPath);

function init(){
  db.prepare(`CREATE TABLE IF NOT EXISTS listings (
    id TEXT PRIMARY KEY,
    title TEXT,
    city TEXT,
    area TEXT,
    price REAL,
    size REAL,
    pricePerSqm REAL,
    type TEXT,
    tags TEXT,
    description TEXT,
    rewrittenDescription TEXT,
    cityMedian REAL,
    source TEXT,
    createdAt TEXT
  )`).run();
}
function insertOrUpdate(listing){
  const stmt = db.prepare(`INSERT INTO listings(id,title,city,area,price,size,pricePerSqm,type,tags,description,rewrittenDescription,cityMedian,source,createdAt)
    VALUES (@id,@title,@city,@area,@price,@size,@pricePerSqm,@type,@tags,@description,@rewrittenDescription,@cityMedian,@source,@createdAt)
    ON CONFLICT(id) DO UPDATE SET
      title=excluded.title,
      city=excluded.city,
      area=excluded.area,
      price=excluded.price,
      size=excluded.size,
      pricePerSqm=excluded.pricePerSqm,
      type=excluded.type,
      tags=excluded.tags,
      description=excluded.description,
      rewrittenDescription=excluded.rewrittenDescription,
      cityMedian=excluded.cityMedian,
      source=excluded.source,
      createdAt=excluded.createdAt
  `);
  stmt.run(listing);
}

function getAll(){
  const rows = db.prepare('SELECT * FROM listings ORDER BY createdAt DESC').all();
  return rows.map(r=>{
    r.tags = r.tags ? JSON.parse(r.tags) : [];
    return r;
  });
}

module.exports = { init, insertOrUpdate, getAll };
