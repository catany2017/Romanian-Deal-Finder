/* Frontend app: fetch listings from server and show cards.
   Assumes server exposes:
   GET /api/listings -> array of listings
   POST /api/refresh -> triggers immediate fetch (optional)
*/
const listingsEl = document.getElementById('listings');
const cityFilter = document.getElementById('cityFilter');
const maxPrice = document.getElementById('maxPrice');
const invType = document.getElementById('invType');
const applyBtn = document.getElementById('applyBtn');
const resetBtn = document.getElementById('resetBtn');
const refreshBtn = document.getElementById('refresh');

let allListings = [];

function computeScore(listing){
  const cityMed = listing.cityMedian || 1700;
  const ratio = listing.pricePerSqm / cityMed;
  let base = Math.max(0, 100 - Math.round((ratio - 0.8) * 80));
  if(listing.tags && listing.tags.includes('near_university')) base += 10;
  if(listing.tags && listing.tags.includes('tourist_area')) base += 8;
  if(listing.tags && listing.tags.includes('needs_reno') && listing.type === 'flip') base += 7;
  base = Math.min(100, base);
  return base;
}

function renderCard(listing){
  const score = computeScore(listing);
  const desc = listing.rewrittenDescription || listing.description || '';
  return `
    <article class="card">
      <h3>${listing.title}</h3>
      <div class="meta">
        <div>${listing.city} • ${listing.area || '—'}</div>
        <div class="price">${Number(listing.price).toLocaleString()} €</div>
        <div class="score">${score}</div>
      </div>
      <div class="meta">
        <div>${listing.pricePerSqm} €/mp</div>
        <div>${listing.size} mp</div>
      </div>
      <p class="desc">${desc}</p>
      <div class="badges">
        ${(listing.tags||[]).map(t=>`<span class="badge">${t.replace('_',' ')}</span>`).join('')}
      </div>
    </article>
  `;
}

async function loadListings(){
  const r = await fetch('/api/listings');
  if(!r.ok) return;
  const data = await r.json();
  allListings = data;
  populateCityFilter();
  showListings(allListings);
}

function populateCityFilter(){
  const cities = Array.from(new Set(allListings.map(l=>l.city))).sort();
  cityFilter.innerHTML = '<option value="all">Toate</option>' + cities.map(c=>`<option value="${c}">${c}</option>`).join('');
}

function showListings(list){
  listingsEl.innerHTML = list.map(renderCard).join('');
}

applyBtn.addEventListener('click', ()=>{
  let res = allListings.slice();
  const city = cityFilter.value;
  if(city !== 'all') res = res.filter(r=>r.city === city);
  const mx = parseFloat(maxPrice.value);
  if(!isNaN(mx)) res = res.filter(r=>r.pricePerSqm <= mx);
  const it = invType.value;
  if(it !== 'all') res = res.filter(r=>r.type === it || (r.tags||[]).includes(it));
  res.sort((a,b)=> computeScore(b) - computeScore(a));
  showListings(res);
});

resetBtn.addEventListener('click', ()=>{
  cityFilter.value = 'all';
  maxPrice.value = '';
  invType.value = 'all';
  showListings(allListings);
});

refreshBtn.addEventListener('click', async (e)=>{
  e.preventDefault();
  await fetch('/api/refresh', {method:'POST'});
  setTimeout(loadListings, 1200);
});

window.addEventListener('DOMContentLoaded', loadListings);
